import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-slip',
  templateUrl: './pay-slip.page.html',
  styleUrls: ['./pay-slip.page.scss'],
})
export class PaySlipPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
