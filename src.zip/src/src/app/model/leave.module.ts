export interface leave{
    reason:string;
    status:string;
    date:string;
    managerName:string;
    userName:String;
}
