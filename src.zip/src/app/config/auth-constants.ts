export class AuthConstants {
  public static readonly AUTH = 'userData'
  };
