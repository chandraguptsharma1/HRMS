export interface Manager{
    name:string;
}