
export interface employee{
    id:string;
    images:string,
    EmpName:string,
    EmpAddress:string,
    MobNo:number,
    JoinDate:string
}