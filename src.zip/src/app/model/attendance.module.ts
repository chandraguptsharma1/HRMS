export interface Attendance{
    id:string,
    
}