export interface EmpSlip{
  id:String;
  month:String;
  imageUrl: String;
  Salary:number;
  }
  