export interface leave{
    id:string;
    reason:string;
    status:string;
    date:string;
    managerName:string;
    userName:String;
}
