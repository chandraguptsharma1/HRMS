import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-week',
  templateUrl: './add-week.page.html',
  styleUrls: ['./add-week.page.scss'],
})
export class AddWeekPage  {

  // bsInlineValue = new Date();
  // bsInlineRangeValue: Date[];
  // maxDate = new Date();
 
  // constructor() {
  //   this.maxDate.setDate(this.maxDate.getDate() + 7);
  //   this.bsInlineRangeValue = [this.bsInlineValue, this.maxDate];
  // }

}
