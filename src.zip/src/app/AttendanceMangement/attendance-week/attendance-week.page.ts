import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attendance-week',
  templateUrl: './attendance-week.page.html',
  styleUrls: ['./attendance-week.page.scss'],
})
export class AttendanceWeekPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
