import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-attendance',
  templateUrl: './add-attendance.page.html',
  styleUrls: ['./add-attendance.page.scss'],
})
export class AddAttendancePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
